
/*
 * Xlib compatibility
 */

/* Nothing yet */
